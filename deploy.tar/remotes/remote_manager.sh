#!/usr/bin/env bash
set -euo pipefail

# -----------------


if [ $# -lt 1 ]; then
    echo "Usage: $0 <command to run on remote server>"
    exit 1
fi

REMOTE_COMMAND="$*"

echo "[1/4] Creating deploy archive…"
git ls-files -z -c -o --exclude-standard \
    | tar --null -T - -cvf "$ARCHIVE"

echo "[2/4] Uploading to remote server…"
scp "$ARCHIVE" "$REMOTE_USER@$REMOTE_HOST:/tmp/$ARCHIVE"

echo "[3/4] Deploying on remote…"
ssh "$REMOTE_USER@$REMOTE_HOST" bash <<EOF
set -euo pipefail
rm -rf "$REMOTE_PATH"
mkdir -p "$REMOTE_PATH"
tar -xvf "/tmp/$ARCHIVE" -C "$REMOTE_PATH"
rm "/tmp/$ARCHIVE"
cd "$REMOTE_PATH"

echo "[4/4] Running command: $REMOTE_COMMAND"
$REMOTE_COMMAND
EOF

echo "✔ Deployment complete."
